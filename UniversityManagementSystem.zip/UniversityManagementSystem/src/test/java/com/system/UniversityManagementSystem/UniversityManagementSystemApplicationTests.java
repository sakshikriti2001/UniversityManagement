package com.system.UniversityManagementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UniversityManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
